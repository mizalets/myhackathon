def bubble_sort(items):

    """Return array of items, sorted in ascending order
    Args:
        items: list or array-like object containing numerical values.

    Returns:
        array : array of items, sorted in ascending order
    Example:
        >>> bubble_sort([20,15,3,])
        [3,15,20]
    """

    """
    docstring goes here
    """
